document.addEventListener("DOMContentLoaded", function() {
    // Menu toggle for small screens
    const menuBtn = document.getElementById("menu-btn");
    const navbar = document.querySelector(".navbar");
    
    menuBtn.addEventListener("click", function() {
        navbar.classList.toggle("active");
    });

    // Form validation
    const form = document.querySelector("form");
    
    form.addEventListener("submit", function(event) {
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const date = document.getElementById("date").value;
        const message = document.getElementById("message").value.trim();
        
        if (name === "" || email === "" || date === "" || message === "") {
            alert("All fields are required!");
            event.preventDefault(); // Prevent form submission
        }
    });
});